import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Filter, Star, MapPin, Clock, Search as SearchIcon } from 'lucide-react';
import { MOCK_PROFESSIONALS } from '../services/mockData';
import { Professional, ServiceCategory } from '../types';

const SearchPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const [professionals, setProfessionals] = useState<Professional[]>(MOCK_PROFESSIONALS);
  const [filterCategory, setFilterCategory] = useState<string>(searchParams.get('category') || 'Todos');
  const [sortBy, setSortBy] = useState<'recommended' | 'price' | 'rating'>('recommended');
  const [urgentOnly, setUrgentOnly] = useState(searchParams.get('urgent') === 'true');

  useEffect(() => {
    // Filter logic
    let filtered = MOCK_PROFESSIONALS;

    // Filter by Category
    if (filterCategory && filterCategory !== 'Todos') {
      filtered = filtered.filter(p => p.category === filterCategory);
    }

    // Filter by Urgency (Available Now)
    if (urgentOnly) {
      filtered = filtered.filter(p => p.isAvailableNow);
    }

    // Sort
    if (sortBy === 'rating') {
      filtered = [...filtered].sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'price') {
      // Simplistic price sort based on cheapest service
      filtered = [...filtered].sort((a, b) => {
        const minA = Math.min(...a.services.map(s => s.price));
        const minB = Math.min(...b.services.map(s => s.price));
        return minA - minB;
      });
    }

    setProfessionals(filtered);
  }, [filterCategory, urgentOnly, sortBy]);

  return (
    <div className="min-h-screen bg-slate-50 pt-6 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-6">
          
          {/* Filters Sidebar */}
          <div className="w-full md:w-64 flex-shrink-0">
            <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                  <Filter size={18} /> Filtros
                </h3>
                <button 
                  onClick={() => {
                    setFilterCategory('Todos');
                    setUrgentOnly(false);
                  }}
                  className="text-xs text-pink-600 hover:underline"
                >
                  Limpar
                </button>
              </div>

              {/* Category Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-slate-700 mb-3">Categoria</h4>
                <div className="space-y-2">
                   <label className="flex items-center">
                      <input 
                        type="radio" 
                        name="category" 
                        checked={filterCategory === 'Todos'} 
                        onChange={() => setFilterCategory('Todos')}
                        className="text-pink-600 focus:ring-pink-500 border-slate-300" 
                      />
                      <span className="ml-2 text-sm text-slate-600">Todas</span>
                    </label>
                  {Object.values(ServiceCategory).map(cat => (
                    <label key={cat} className="flex items-center">
                      <input 
                        type="radio" 
                        name="category" 
                        checked={filterCategory === cat} 
                        onChange={() => setFilterCategory(cat)}
                        className="text-pink-600 focus:ring-pink-500 border-slate-300" 
                      />
                      <span className="ml-2 text-sm text-slate-600">{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Toggle Switches */}
              <div className="mb-6">
                <label className="flex items-center justify-between cursor-pointer group">
                  <span className="text-sm font-medium text-slate-700">Disponível Agora</span>
                  <div 
                    onClick={() => setUrgentOnly(!urgentOnly)}
                    className={`w-10 h-6 flex items-center bg-slate-200 rounded-full p-1 duration-300 ease-in-out ${urgentOnly ? 'bg-green-500' : ''}`}
                  >
                    <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${urgentOnly ? 'translate-x-4' : ''}`}></div>
                  </div>
                </label>
              </div>

               {/* Map Placeholder */}
               <div className="mt-8">
                 <h4 className="text-sm font-medium text-slate-700 mb-3">Mapa</h4>
                 <div className="bg-slate-200 h-32 rounded-lg flex items-center justify-center text-slate-400">
                    <div className="text-center">
                        <MapPin className="mx-auto mb-1" />
                        <span className="text-xs">Visualização no Mapa</span>
                    </div>
                 </div>
               </div>

            </div>
          </div>

          {/* Results List */}
          <div className="flex-grow">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-slate-800">
                {professionals.length} profissionais encontrados
              </h2>
              <select 
                value={sortBy} 
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border-slate-200 rounded-lg text-sm text-slate-600 py-2 pl-3 pr-8 focus:ring-pink-500 focus:border-pink-500"
              >
                <option value="recommended">Recomendados</option>
                <option value="rating">Melhor Avaliados</option>
                <option value="price">Menor Preço</option>
              </select>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {professionals.map(pro => (
                <div key={pro.id} className="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:shadow-md transition flex flex-col sm:flex-row gap-4">
                  {/* Image */}
                  <div className="relative w-full sm:w-48 h-48 sm:h-auto flex-shrink-0">
                    <img 
                        src={pro.imageUrl} 
                        alt={pro.name} 
                        className="w-full h-full object-cover rounded-lg"
                    />
                    {pro.isAvailableNow && (
                        <span className="absolute top-2 left-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded shadow-sm">
                            Agenda Aberta
                        </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-grow flex flex-col justify-between">
                    <div>
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-lg font-bold text-slate-900">{pro.name}</h3>
                                <p className="text-sm text-slate-500 mb-2">{pro.category}</p>
                            </div>
                            <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-md">
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                                <span className="text-sm font-bold text-slate-700">{pro.rating}</span>
                                <span className="text-xs text-slate-400 ml-1">({pro.reviewCount})</span>
                            </div>
                        </div>
                        
                        <div className="flex items-center text-slate-500 text-sm mb-3">
                            <MapPin className="h-4 w-4 mr-1" />
                            {pro.address} • {pro.distanceKm}km
                        </div>

                        <div className="flex flex-wrap gap-2 mb-4">
                            {pro.services.slice(0, 3).map(service => (
                                <span key={service.id} className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">
                                    {service.name}
                                </span>
                            ))}
                            {pro.services.length > 3 && (
                                <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">
                                    +{pro.services.length - 3}
                                </span>
                            )}
                        </div>
                    </div>

                    <div className="flex items-center justify-between border-t border-slate-100 pt-3">
                        <div className="text-xs text-slate-500">
                             <span className="block">Próximo horário:</span>
                             <span className="font-semibold text-green-600">{pro.isAvailableNow ? 'Hoje, 14:30' : 'Amanhã, 09:00'}</span>
                        </div>
                        <button 
                            onClick={() => navigate(`/professional/${pro.id}`)}
                            className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2 rounded-lg text-sm font-medium transition"
                        >
                            Ver Perfil
                        </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchPage;