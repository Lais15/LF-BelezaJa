import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Star, MapPin, Clock, CheckCircle, ChevronRight, Calendar as CalendarIcon, X } from 'lucide-react';
import { MOCK_PROFESSIONALS } from '../services/mockData';
import { ServiceItem } from '../types';
import toast from 'react-hot-toast';

const ProfessionalProfile: React.FC = () => {
  const { id } = useParams();
  const professional = MOCK_PROFESSIONALS.find(p => p.id === id);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  if (!professional) return <div className="p-10 text-center">Profissional não encontrado</div>;

  const handleBookClick = (service: ServiceItem) => {
    setSelectedService(service);
    setIsBookingModalOpen(true);
  };

  const confirmBooking = () => {
    toast.success('Agendamento confirmado com sucesso! Verifique seu email.');
    setIsBookingModalOpen(false);
    setSelectedService(null);
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      {/* Header / Cover */}
      <div className="relative h-64 w-full">
        <img src={professional.coverUrl} alt="Cover" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 to-transparent"></div>
        <div className="absolute bottom-4 left-4 md:left-8 flex items-end">
            <img src={professional.imageUrl} alt={professional.name} className="w-24 h-24 rounded-full border-4 border-white shadow-lg object-cover" />
            <div className="ml-4 mb-2 text-white">
                <h1 className="text-2xl font-bold">{professional.name}</h1>
                <p className="text-slate-200 text-sm flex items-center">
                    <MapPin className="h-3 w-3 mr-1" /> {professional.address}
                </p>
            </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column: Services & Info */}
            <div className="md:col-span-2 space-y-6">
                {/* About */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
                    <h2 className="text-lg font-bold text-slate-800 mb-3">Sobre</h2>
                    <p className="text-slate-600 leading-relaxed">{professional.about}</p>
                    <div className="flex gap-4 mt-4 text-sm text-slate-500">
                        <div className="flex items-center"><Star className="h-4 w-4 mr-1 text-yellow-500" /> {professional.rating} ({professional.reviewCount} avaliações)</div>
                        <div className="flex items-center"><Clock className="h-4 w-4 mr-1" /> Seg - Sáb, 09:00 - 19:00</div>
                    </div>
                </div>

                {/* Services List */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
                    <h2 className="text-lg font-bold text-slate-800 mb-4">Serviços</h2>
                    <div className="space-y-4">
                        {professional.services.map(service => (
                            <div key={service.id} className="flex items-center justify-between p-3 border border-slate-100 rounded-lg hover:border-pink-200 transition">
                                <div>
                                    <h3 className="font-medium text-slate-900">{service.name}</h3>
                                    <p className="text-xs text-slate-500">{service.durationMinutes} min</p>
                                </div>
                                <div className="flex items-center gap-4">
                                    <span className="font-semibold text-slate-900">R$ {service.price.toFixed(2)}</span>
                                    <button 
                                        onClick={() => handleBookClick(service)}
                                        className="bg-pink-600 text-white px-4 py-1.5 rounded-lg text-sm font-medium hover:bg-pink-700 transition"
                                    >
                                        Agendar
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Reviews */}
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
                     <h2 className="text-lg font-bold text-slate-800 mb-4">Avaliações</h2>
                     {professional.reviews.length > 0 ? (
                        professional.reviews.map(review => (
                            <div key={review.id} className="border-b border-slate-100 last:border-0 py-3">
                                <div className="flex justify-between mb-1">
                                    <span className="font-medium text-slate-900">{review.author}</span>
                                    <span className="text-xs text-slate-400">{review.date}</span>
                                </div>
                                <div className="flex text-yellow-400 text-xs mb-2">
                                    {[...Array(5)].map((_, i) => (
                                        <Star key={i} size={12} fill={i < review.rating ? "currentColor" : "none"} />
                                    ))}
                                </div>
                                <p className="text-slate-600 text-sm">{review.comment}</p>
                            </div>
                        ))
                     ) : (
                         <p className="text-slate-500 italic">Nenhuma avaliação recente.</p>
                     )}
                </div>
            </div>

            {/* Right Column: Portfolio & Quick Info */}
            <div className="space-y-6">
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
                    <h2 className="text-lg font-bold text-slate-800 mb-4">Portfólio</h2>
                    <div className="grid grid-cols-2 gap-2">
                        {professional.portfolio.map((img, i) => (
                            <img key={i} src={img} alt="Portfolio" className="w-full h-24 object-cover rounded-lg hover:opacity-90 cursor-pointer" />
                        ))}
                    </div>
                </div>
                
                <div className="bg-slate-900 rounded-xl p-6 text-white shadow-lg">
                    <h3 className="font-bold text-lg mb-2">LF BelezaJá</h3>
                    <p className="text-sm text-slate-300 mb-4">Garanta seu horário sem sair de casa. Pagamento seguro pelo app.</p>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                        <CheckCircle size={14} className="text-green-400" /> Profissional Verificado
                    </div>
                </div>
            </div>
        </div>
      </div>

      {/* Booking Modal Overlay */}
      {isBookingModalOpen && selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl relative animate-in fade-in zoom-in duration-200">
                <button 
                    onClick={() => setIsBookingModalOpen(false)}
                    className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
                >
                    <X size={20} />
                </button>

                <h2 className="text-xl font-bold text-slate-900 mb-1">Confirmar Agendamento</h2>
                <p className="text-slate-500 text-sm mb-6">Você está a um passo de garantir seu horário.</p>

                <div className="bg-slate-50 p-4 rounded-xl mb-6">
                    <div className="flex justify-between items-center mb-2">
                        <span className="text-slate-600 font-medium">{selectedService.name}</span>
                        <span className="text-slate-900 font-bold">R$ {selectedService.price.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm text-slate-500">
                        <span>Duração estimada</span>
                        <span>{selectedService.durationMinutes} min</span>
                    </div>
                </div>

                <div className="space-y-3 mb-6">
                    <label className="block text-sm font-medium text-slate-700">Escolha o horário</label>
                    <div className="grid grid-cols-3 gap-2">
                        {['14:00', '15:30', '17:00'].map(time => (
                            <button key={time} className="border border-slate-200 rounded-lg py-2 text-sm hover:border-pink-500 hover:bg-pink-50 focus:bg-pink-100 focus:border-pink-600 focus:ring-1 focus:ring-pink-600 transition">
                                {time}
                            </button>
                        ))}
                    </div>
                </div>

                <button 
                    onClick={confirmBooking}
                    className="w-full bg-pink-600 text-white font-bold py-3 rounded-xl hover:bg-pink-700 transition shadow-lg shadow-pink-600/30"
                >
                    Confirmar e Pagar
                </button>
            </div>
        </div>
      )}
    </div>
  );
};

export default ProfessionalProfile;