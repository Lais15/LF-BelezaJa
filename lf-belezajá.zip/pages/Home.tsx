import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Sparkles, ArrowRight, Loader2, Scissors } from 'lucide-react';
import { ServiceCategory, UserState } from '../types';
import { getSmartRecommendations } from '../services/geminiService';
import toast from 'react-hot-toast';

interface HomeProps {
  user: UserState;
}

const Home: React.FC<HomeProps> = ({ user }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleCategoryClick = (category: string) => {
    navigate(`/search?category=${encodeURIComponent(category)}`);
  };

  const handleSmartSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsAiLoading(true);
    const recommendation = await getSmartRecommendations(searchQuery);
    setIsAiLoading(false);

    if (recommendation) {
      toast.success(`Entendi! Buscando por ${recommendation.suggestedCategory}`, { icon: '✨' });
      const params = new URLSearchParams();
      params.append('category', recommendation.suggestedCategory);
      if (recommendation.isUrgent) params.append('urgent', 'true');
      navigate(`/search?${params.toString()}`);
    } else {
        // Fallback to basic search
       navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <div className="relative bg-slate-900 text-white overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1560066984-138dadb4c035?q=80&w=2574&auto=format&fit=crop" 
            alt="Beauty Salon Background" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-32">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
            Sua beleza, <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">seu tempo.</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-300 max-w-2xl mb-10">
            Encontre os melhores profissionais de beleza próximos a você e agende em segundos. Cabelo, unhas, barbearia e muito mais.
          </p>

          {/* Search Box */}
          <div className="max-w-3xl bg-white rounded-2xl shadow-xl p-2 md:p-3 flex flex-col md:flex-row gap-2">
            <div className="flex-grow relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Sparkles className="h-5 w-5 text-pink-500" />
                </div>
                <form onSubmit={handleSmartSearch}>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Ex: Preciso de uma make para casamento hoje..."
                        className="block w-full pl-10 pr-3 py-3 border-none text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-0 rounded-xl bg-transparent"
                    />
                </form>
            </div>
            
            <div className="md:border-l md:border-slate-200 md:pl-2 flex-shrink-0 relative">
                 <button 
                    onClick={() => {
                        if (navigator.geolocation) {
                             navigator.geolocation.getCurrentPosition(() => {
                                 toast.success("Localização atualizada!");
                             }, () => {
                                 toast.error("Erro ao obter localização");
                             });
                        }
                    }}
                    className="flex items-center w-full md:w-auto px-4 py-3 text-slate-500 hover:text-slate-800 transition"
                >
                    <MapPin className="h-5 w-5 mr-2" />
                    <span className="text-sm font-medium">Local Atual</span>
                </button>
            </div>

            <button 
                onClick={handleSmartSearch}
                disabled={isAiLoading}
                className="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-8 rounded-xl transition shadow-lg shadow-pink-600/30 flex items-center justify-center"
            >
                {isAiLoading ? <Loader2 className="animate-spin h-5 w-5" /> : 'Buscar'}
            </button>
          </div>
          
          <div className="mt-4 flex items-center gap-2 text-sm text-slate-400">
             <span className="bg-white/10 px-2 py-1 rounded text-xs border border-white/20">IA Powered</span>
             <span>Experimente buscar por "Corte de cabelo perto de mim urgente"</span>
          </div>
        </div>
      </div>

      {/* Categories Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 -mt-20 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4">
          {Object.entries(ServiceCategory).map(([key, label]) => (
            <div 
                key={key} 
                onClick={() => handleCategoryClick(label)}
                className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all cursor-pointer transform hover:-translate-y-1 group border border-slate-100"
            >
                <div className="h-12 w-12 bg-pink-50 rounded-lg flex items-center justify-center text-pink-600 mb-4 group-hover:bg-pink-600 group-hover:text-white transition-colors">
                    {/* Simple icon mapping based on index or randomness for demo */}
                    <Scissors size={24} />
                </div>
                <h3 className="font-semibold text-slate-900 group-hover:text-pink-600 transition-colors">{label}</h3>
                <p className="text-xs text-slate-500 mt-1">Ver profissionais</p>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Section */}
      <div className="bg-slate-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center gap-12">
                <div className="flex-1">
                    <h2 className="text-3xl font-bold text-slate-900 mb-4">Agende em tempo real, sem telefonemas.</h2>
                    <p className="text-slate-600 mb-6 leading-relaxed">
                        Esqueça a demora para conseguir um horário. Com o LF BelezaJá, você vê quem está livre agora e agenda com um clique. Pagamento fácil e seguro.
                    </p>
                    <ul className="space-y-3 mb-8">
                        {['Disponibilidade em tempo real', 'Avaliações verificadas', 'Pagamento via App'].map((item, i) => (
                            <li key={i} className="flex items-center text-slate-700">
                                <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mr-3 text-xs">✓</div>
                                {item}
                            </li>
                        ))}
                    </ul>
                    <button 
                        onClick={() => navigate('/search')}
                        className="text-pink-600 font-semibold flex items-center hover:text-pink-700 transition"
                    >
                        Explorar todos os serviços <ArrowRight className="ml-2 h-4 w-4" />
                    </button>
                </div>
                <div className="flex-1 relative">
                    <div className="absolute -inset-4 bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl opacity-20 blur-lg"></div>
                    <img 
                        src="https://images.unsplash.com/photo-1633681926022-84c23e8cb2d6?q=80&w=2664&auto=format&fit=crop" 
                        alt="App usage" 
                        className="relative rounded-2xl shadow-2xl"
                    />
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Home;