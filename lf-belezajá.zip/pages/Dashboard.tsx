import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { UserState, UserType } from '../types';
import { MOCK_APPOINTMENTS } from '../services/mockData';
import { Calendar, DollarSign, Users, Clock } from 'lucide-react';

interface DashboardProps {
  user: UserState;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  if (user.type !== UserType.PROFESSIONAL) {
    return (
        <div className="h-[50vh] flex flex-col items-center justify-center text-slate-500">
            <h2 className="text-xl font-bold text-slate-800 mb-2">Acesso Restrito</h2>
            <p>Por favor, altere para o modo "Profissional" no menu superior.</p>
        </div>
    );
  }

  // Mock data for charts
  const data = [
    { name: 'Seg', agendamentos: 4 },
    { name: 'Ter', agendamentos: 6 },
    { name: 'Qua', agendamentos: 8 },
    { name: 'Qui', agendamentos: 5 },
    { name: 'Sex', agendamentos: 12 },
    { name: 'Sáb', agendamentos: 15 },
    { name: 'Dom', agendamentos: 2 },
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Painel de Controle</h1>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">Ganhos (Mês)</span>
                    <DollarSign className="text-green-500 h-5 w-5" />
                </div>
                <div className="text-2xl font-bold text-slate-800">R$ 4.250,00</div>
                <div className="text-xs text-green-600 mt-1">+12% vs mês anterior</div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">Agendamentos</span>
                    <Calendar className="text-blue-500 h-5 w-5" />
                </div>
                <div className="text-2xl font-bold text-slate-800">42</div>
                <div className="text-xs text-slate-400 mt-1">Nesta semana</div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">Clientes Novos</span>
                    <Users className="text-purple-500 h-5 w-5" />
                </div>
                <div className="text-2xl font-bold text-slate-800">18</div>
                <div className="text-xs text-purple-600 mt-1">Recorde mensal!</div>
            </div>

             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-sm">Horas Trabalhadas</span>
                    <Clock className="text-orange-500 h-5 w-5" />
                </div>
                <div className="text-2xl font-bold text-slate-800">38h</div>
                <div className="text-xs text-slate-400 mt-1">Meta: 40h</div>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Chart */}
            <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <h3 className="font-bold text-slate-800 mb-6">Atendimentos na Semana</h3>
                <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                            <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                            <Tooltip 
                                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                                cursor={{fill: '#f1f5f9'}}
                            />
                            <Bar dataKey="agendamentos" fill="#db2777" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <h3 className="font-bold text-slate-800 mb-4">Próximos Clientes</h3>
                <div className="space-y-4">
                    {MOCK_APPOINTMENTS.filter(a => a.status !== 'COMPLETED').map((apt) => (
                        <div key={apt.id} className="flex items-start p-3 hover:bg-slate-50 rounded-lg transition border border-transparent hover:border-slate-100">
                            <div className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold mr-3">
                                {apt.serviceName.substring(0,2).toUpperCase()}
                            </div>
                            <div>
                                <h4 className="font-medium text-slate-900">{apt.serviceName}</h4>
                                <p className="text-sm text-slate-500">{apt.date} às {apt.time}</p>
                                <span className={`text-xs px-2 py-0.5 rounded-full ${apt.status === 'CONFIRMED' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                    {apt.status}
                                </span>
                            </div>
                        </div>
                    ))}
                    {MOCK_APPOINTMENTS.filter(a => a.status !== 'COMPLETED').length === 0 && (
                        <p className="text-slate-400 text-sm italic">Nenhum agendamento futuro.</p>
                    )}
                </div>
                <button className="w-full mt-6 border border-slate-200 text-slate-600 py-2 rounded-lg text-sm font-medium hover:bg-slate-50 transition">
                    Ver agenda completa
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;