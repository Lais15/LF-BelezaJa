import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Search, Calendar, User, Menu, X, Scissors, LogOut, LayoutDashboard } from 'lucide-react';
import { UserType, UserState } from '../types';

interface NavbarProps {
  user: UserState;
  setUser: (u: UserState) => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, setUser }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const toggleUserType = () => {
    const newType = user.type === UserType.CLIENT ? UserType.PROFESSIONAL : UserType.CLIENT;
    setUser({ ...user, type: newType, name: newType === UserType.CLIENT ? 'Julia Client' : 'Carlos Profissional' });
    if (newType === UserType.PROFESSIONAL) {
      navigate('/dashboard');
    } else {
      navigate('/');
    }
    setIsMenuOpen(false);
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center gap-2 cursor-pointer">
              <div className="bg-gradient-to-tr from-pink-500 to-purple-600 p-2 rounded-lg">
                <Scissors className="h-6 w-6 text-white" />
              </div>
              <span className="font-bold text-xl tracking-tight text-slate-800">
                LF Beleza<span className="text-pink-600">Já</span>
              </span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {user.type === UserType.CLIENT ? (
              <>
                <Link to="/" className={`text-sm font-medium transition-colors ${isActive('/') ? 'text-pink-600' : 'text-slate-600 hover:text-pink-600'}`}>
                  Início
                </Link>
                <Link to="/search" className={`text-sm font-medium transition-colors ${isActive('/search') ? 'text-pink-600' : 'text-slate-600 hover:text-pink-600'}`}>
                  Explorar
                </Link>
                <Link to="/appointments" className="text-slate-600 hover:text-pink-600 text-sm font-medium">
                  Meus Agendamentos
                </Link>
              </>
            ) : (
              <>
                <Link to="/dashboard" className={`flex items-center gap-1 text-sm font-medium transition-colors ${isActive('/dashboard') ? 'text-pink-600' : 'text-slate-600 hover:text-pink-600'}`}>
                  <LayoutDashboard size={16} /> Dashboard
                </Link>
                <Link to="/schedule" className="text-slate-600 hover:text-pink-600 text-sm font-medium">
                  Minha Agenda
                </Link>
              </>
            )}

            <div className="flex items-center border-l pl-6 border-slate-200 gap-4">
              <button 
                onClick={toggleUserType}
                className="text-xs font-semibold px-3 py-1 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 transition"
              >
                Modo: {user.type === UserType.CLIENT ? 'Cliente' : 'Profissional'}
              </button>
              
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-600">
                  <User size={18} />
                </div>
                <span className="text-sm font-medium text-slate-700">{user.name}</span>
              </div>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-slate-500 hover:bg-slate-100 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
             {user.type === UserType.CLIENT ? (
              <>
                <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-pink-600 hover:bg-slate-50">Início</Link>
                <Link to="/search" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-pink-600 hover:bg-slate-50">Explorar</Link>
              </>
            ) : (
               <Link to="/dashboard" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-pink-600 hover:bg-slate-50">Dashboard</Link>
            )}
            <button 
                onClick={toggleUserType}
                className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-indigo-600 hover:bg-indigo-50 mt-2 border-t"
              >
                Trocar para {user.type === UserType.CLIENT ? 'Profissional' : 'Cliente'}
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;