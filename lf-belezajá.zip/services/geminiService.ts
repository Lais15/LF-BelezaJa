import { GoogleGenAI, Type } from "@google/genai";
import { ServiceCategory } from '../types';

const apiKey = process.env.API_KEY || ''; // In a real app, ensure this is set securely
const ai = new GoogleGenAI({ apiKey });

// Schema for interpreting user intent
interface RecommendationResponse {
  suggestedCategory: string;
  isUrgent: boolean;
  reasoning: string;
  keywords: string[];
}

export const getSmartRecommendations = async (userQuery: string): Promise<RecommendationResponse | null> => {
  if (!apiKey) {
    console.warn("API Key missing for Gemini");
    return null;
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `O usuário está buscando um serviço de beleza com a seguinte consulta: "${userQuery}".
      Analise a intenção.
      As categorias disponíveis são: ${Object.values(ServiceCategory).join(', ')}.
      Retorne JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestedCategory: { type: Type.STRING, description: "A categoria mais próxima das disponíveis" },
            isUrgent: { type: Type.BOOLEAN, description: "Se o usuário expressa urgência (ex: 'agora', 'hoje', 'rápido')" },
            reasoning: { type: Type.STRING, description: "Breve explicação da escolha" },
            keywords: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "Palavras-chave para refinar busca" 
            }
          },
          required: ["suggestedCategory", "isUrgent", "keywords"]
        }
      }
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text) as RecommendationResponse;
    }
    return null;

  } catch (error) {
    console.error("Gemini API Error:", error);
    return null;
  }
};