import { Professional, ServiceCategory, Appointment } from '../types';

export const MOCK_PROFESSIONALS: Professional[] = [
  {
    id: '1',
    name: 'Ana Silva Beauty',
    category: ServiceCategory.HAIR,
    rating: 4.9,
    reviewCount: 124,
    imageUrl: 'https://picsum.photos/id/64/200/200',
    coverUrl: 'https://picsum.photos/id/429/800/300',
    address: 'Rua das Flores, 123 - Centro',
    distanceKm: 1.2,
    isAvailableNow: true,
    about: 'Especialista em coloração e cortes modernos. Mais de 10 anos de experiência transformando visuais.',
    services: [
      { id: 's1', name: 'Corte Feminino', price: 120, durationMinutes: 60 },
      { id: 's2', name: 'Mechas', price: 350, durationMinutes: 180 },
      { id: 's3', name: 'Hidratação Profunda', price: 150, durationMinutes: 45 },
    ],
    reviews: [
      { id: 'r1', author: 'Mariana X.', rating: 5, comment: 'Amei o resultado!', date: '2023-10-15' }
    ],
    portfolio: [
      'https://picsum.photos/id/823/400/400',
      'https://picsum.photos/id/822/400/400',
      'https://picsum.photos/id/821/400/400'
    ]
  },
  {
    id: '2',
    name: 'Barbearia Viking',
    category: ServiceCategory.BARBER,
    rating: 4.7,
    reviewCount: 89,
    imageUrl: 'https://picsum.photos/id/91/200/200',
    coverUrl: 'https://picsum.photos/id/338/800/300',
    address: 'Av. Paulista, 2000',
    distanceKm: 3.5,
    isAvailableNow: false,
    about: 'Ambiente clássico, cerveja gelada e o melhor corte da região.',
    services: [
      { id: 's4', name: 'Corte Masculino', price: 60, durationMinutes: 40 },
      { id: 's5', name: 'Barba Terapia', price: 50, durationMinutes: 30 },
      { id: 's6', name: 'Combo (Corte + Barba)', price: 100, durationMinutes: 60 },
    ],
    reviews: [],
    portfolio: ['https://picsum.photos/id/800/400/400']
  },
  {
    id: '3',
    name: 'Studio Glamour Nails',
    category: ServiceCategory.NAILS,
    rating: 4.8,
    reviewCount: 215,
    imageUrl: 'https://picsum.photos/id/43/200/200',
    coverUrl: 'https://picsum.photos/id/442/800/300',
    address: 'Rua Augusta, 500',
    distanceKm: 0.8,
    isAvailableNow: true,
    about: 'Unhas de gel, fibra e nail art artística. Cuide das suas mãos conosco.',
    services: [
      { id: 's7', name: 'Manicure', price: 40, durationMinutes: 30 },
      { id: 's8', name: 'Pedicure', price: 45, durationMinutes: 40 },
      { id: 's9', name: 'Alongamento em Gel', price: 180, durationMinutes: 120 },
    ],
    reviews: [],
    portfolio: ['https://picsum.photos/id/700/400/400', 'https://picsum.photos/id/701/400/400']
  },
  {
    id: '4',
    name: 'Estética Zen',
    category: ServiceCategory.ESTHETICS,
    rating: 5.0,
    reviewCount: 42,
    imageUrl: 'https://picsum.photos/id/65/200/200',
    coverUrl: 'https://picsum.photos/id/500/800/300',
    address: 'Rua do Bosque, 88',
    distanceKm: 5.0,
    isAvailableNow: false,
    about: 'Massagens relaxantes e tratamentos faciais.',
    services: [
      { id: 's10', name: 'Limpeza de Pele', price: 150, durationMinutes: 90 },
      { id: 's11', name: 'Massagem Relaxante', price: 180, durationMinutes: 60 },
    ],
    reviews: [],
    portfolio: []
  }
];

export const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: 'a1',
    professionalName: 'Ana Silva Beauty',
    serviceName: 'Corte Feminino',
    date: '2023-11-20',
    time: '14:00',
    price: 120,
    status: 'CONFIRMED'
  },
  {
    id: 'a2',
    professionalName: 'Barbearia Viking',
    serviceName: 'Barba Terapia',
    date: '2023-11-18',
    time: '10:00',
    price: 50,
    status: 'COMPLETED'
  }
];